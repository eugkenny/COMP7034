public class Board{
    public Board(int [][] tiles){
        // YOUR CODE HERE
    }
    
    public int hamming(){
        // YOUR CODE HERE
        return 0;
    }
    
    public int manhattan(){
        // YOUR CODE HERE
        return 0;
    }
    
    public boolean equals( Object o){
        // YOUR CODE HERE
        return false;
    }
    
    public Iterable<Board> neighbours(){
        // YOUR CODE HERE
        return null;
    }
    
    public String toString(){
        // YOUR CODE HERE
        return "";
    }
}
        